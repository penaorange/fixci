<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of login_model
 *
 * @author abdullah
 */
class Model_login extends CI_Model {

    //put your code here

    function __construct() {
        parent::__construct();
    }

	 public function login($username, $password) {
        //create query to connect user login database
        $this->db->select('*');
        $this->db->from('peserta');
        $this->db->where('username', $username);
        $this->db->where('password', $password);
        $this->db->where('konfirmasi', 1);
        
        $this->db->where('id_peserta IS NOT NULL');
        $this->db->limit(1);

        //get query and processing
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->result(); //if data is true
        } else {
            return false; //if data is wrong
        }
    }

    public function getNama($id_peserta) {
        $this->db->select('*');
        $this->db->from('peserta');
        $this->db->where('id_peserta', $id_peserta);
        $this->db->limit(1);
        //get query and processing
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->result(); //if data is true
        } else {
            return "error"; //if data is wrong
        }
    }

    public function loginAdmin($username, $password) {
        //create query to connect user login database
        $this->db->select('*');
        $this->db->from('admin');
        $this->db->where('username', $username);
        $this->db->where('password', $password);
        
        $this->db->where('id_admin IS NOT NULL');
        $this->db->limit(1);

        //get query and processing
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->result(); //if data is true
        } else {
            return false; //if data is wrong
        }
    }

    public function getAdmin($id_admin) {
        $this->db->select('*');
        $this->db->from('admin');
        $this->db->where('id_admin', $id_admin);
        $this->db->limit(1);
        //get query and processing
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->result(); //if data is true
        } else {
            return "error"; //if data is wrong
        }
    }


    public function insertPeserta($data){
        $this->db->insert('peserta', $data);
    }
    
    function get_hash_value($email){
        $this->db->select('hash');
        $this->db->from('peserta');
        $this->db->where('email',$email);
        
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->result(); //if data is true
        } else {
            return false; //if data is wrong
        }
          
    }
    
    function verify_user($email){
        $this->db->query("update peserta set konfirmasi = 1 where email ='$email'");
    }

}
?>
