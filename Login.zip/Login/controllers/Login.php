<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MX_Controller {

public function __construct()
    {
        parent::__construct();
        //$this->load->library('l_admin');
        $this->load->helper('url');
        $this->load->model('Model_login');
        // $this->load->library('pagination');
        
        
    } 

    function index() {
        //pengecekan session dari halaman admin
       	    if($this->session->userdata('id_admin')){
       	    	redirect(site_url('Dashboard'));
       	    }else{
       	     	$this->load->view('View_login');
       	    }
    }
        

    function ceklogin() {                  
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        //jika tidak ada yang di inputkan ke dalam username/password
        if (empty($username)||empty($password) ) {
            redirect(site_url('Login'));
        }

        //query  database        
        $resultUser = $this->Model_login->login($username, $password);
        //$resultAdmin = $this->Model_login->loginAdmin($username, $password);
        
        //jika menggunakan username user
         if ($resultUser) {
            $sess_array = array();
            foreach ($resultUser as $row) {
                $result2 = $this->Model_login->getNama($row->id_peserta);                
                foreach ($result2 as $row2) {
                    $nama = $row2->nama;
                    $status = $row2->status;
                }
                //membuat session
                $sess_array = array(             
                    'id_peserta' => $row->id_peserta,
                    'USERNAME' => $row->username,
                    'PASSWORD' => $row->password,
                    'STATUS' => $status,
                    // 'login_peserta' => true,
                );
                $this->session->set_userdata($sess_array);

                //pengecekan hak akses peserta
                if ($status == 0) {
                    redirect(site_url('peserta-free'));
                } elseif($status == 1){
                    redirect(site_url('peserta-berbayar'));
                } elseif($status == 2){
                    redirect(site_url('peserta-bimbel'));
                } else{
                    redirect(site_url('Login'));
                }
                
            }
            return TRUE;
        
        } else if ($username=='cermatin' && $password=='admincermat') {
            $sess_array = array();
                //membuat session
                $sess_array = array(             
                    'id_admin' => 'adm01',
                    'USERNAME_ADMIN' => 'Admin',
                );
                $this->session->set_userdata($sess_array);
                redirect('Dashboard','refresh');
                
                
            
        
        } else {
            //if form validate false
            $this->session->set_flashdata('notif', 'username atau password yang anda masukan salah atau anda belum mengaktifkan akun anda');
            redirect(site_url('Login'));
            return FALSE;
        }

    }

    function logout() {
        // $level_akun = $this->uri->segment(1);
        $this->session->unset_userdata("id_peserta");
        $this->session->unset_userdata("USERNAME");
        $this->session->unset_userdata("STATUS");
        $this->session->unset_userdata("USERNAME_ADMIN");
        $this->session->unset_userdata("PASSWORD_ADMIN");
        $this->session->unset_userdata("id_admin");
        $this->session->set_flashdata('terimakasih', 'Terima kasih telah menggunakan aplikasi kami');
        redirect(site_url('Login'));
    }

    function halamanDaftar(){
        $this->load->view('View_daftar');
    }

     function daftar() {
	$this->data = array(
	'nama'=> htmlspecialchars($this->input->post('nama')),
        'jenis_kelamin'=> htmlspecialchars($this->input->post('jeniskelamin')),
       'no_hp'=> htmlspecialchars($this->input->post('nohp')),
        'kelompok_ujian'=> htmlspecialchars($this->input->post('kelompokujian')),
        'email'=> htmlspecialchars($this->input->post('email')),
       'alamat'=> htmlspecialchars($this->input->post('alamat')),
        'username'=> htmlspecialchars($this->input->post('username')),
        'password'=> htmlspecialchars($this->input->post('password')),
        'status'=> '0',
        'hash'=> md5(rand(0,1000))
	);
       


        $this->Model_login->insertPeserta($this->data);
        
        $this->session->set_userdata($this->input->post('nama').$this->input->post('nohp'),1);
        $this->sendMail(htmlspecialchars($this->input->post('email')));
        
        redirect(site_url('Login'));
    }
   function sendMail($email){
     $config = Array(
    'protocol' => 'smtp',
    'smtp_host' => 'ssl://smtp.gmail.com',
    'smtp_port' => 465,
    'smtp_user' => 'suport.cermatinstitute@gmail.com', // change it to yours
    'smtp_pass' => '1mZDr779nk', // change it to yours
    'mailtype' => 'html',
    'charset' => 'iso-8859-1',
    'wordwrap' => TRUE
  );

      
       $this->load->library('email', $config);
       $this->email->set_newline("\r\n");  
       $this->email->from('Cermat Institute'); // change it to yours
       $this->email->to($email);// change it to yours
       
        $message= /*-----------email body starts-----------*/
        "Terima kasih telah mendaftar, ".$_POST['nama']."!
      
        
        Berikut detail akun anda:
        
        Email   : " . $_POST['email'] . "
        Password: " . $_POST['password'] . "
       
                        
        Klik link berikut untuk aktivasi akun anda:
            
        " . base_url() . "Login/konfirmasi?" . 
        "email=" . $_POST['email'] . "&hash=" . $this->data['hash'] ;
		/*-----------email body ends-----------*/		
       
       
       
       $this->email->subject('Aktifasi akun');
       $this->email->message($message);
      $this->email->send();
 }
 
 function konfirmasi(){
 	 $result = $this->Model_login->get_hash_value($_GET['email']); 
         if($result){ 
         foreach ($result as $value){
         
         
         if($value->hash ==$_GET['hash']){  
                $this->Model_login->verify_user($_GET['email']);
                redirect('Login');
            }else{
         	echo "gagal nyamain";   
            }
         }
         }else{
         echo "gagal eksekusi";
         }
 }

}
