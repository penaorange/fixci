<?php $this->load->view('PesertaModular/Berbayar/Header'); ?>
<!-- start-modular -->

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10 col-md-offset-1">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Email Statistics</h4>
                                <p class="category">Last Campaign Performance</p>
                            </div>
                            <div class="content">

                              <div class="row">
                                <div class="col-xs-4 col-md-4 col-lg-4">

                                </div>

                                <div class="col-xs-8 col-md-8 col-lg-8">
                                  <img src="<?php echo base_url(); ?>/assets/peserta/img/CI2.jpg" class="img-circle"/>
                                </div>

                              </div>

                                <div class="footer">
                                    <div class="legend">
                                        <i class="fa fa-circle text-info"></i> Open
                                        <i class="fa fa-circle text-danger"></i> Bounce
                                        <i class="fa fa-circle text-warning"></i> Unsubscribe
                                    </div>
                                    <hr>
                                    <div class="stats">
                                        <i class="fa fa-clock-o"></i> Campaign sent 2 days ago
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>




            </div>
        </div>

<!-- end modular -->
<?php $this->load->view('PesertaModular/Berbayar/Footer'); ?>
