<?php $this->load->view('PesertaModular/Free/Header_test'); ?>
<!-- start-modular -->

<div class="content">
            <div class="container-fluid">
                <div class="row">
					<div class="col-md-6 col-md-offset-3">
                        <div class="card">
                          <?php if (empty($nama_mapel) && empty($soal)): ?>
                            <div class="content tryout-soal">
                                <div class="alert alert-warning">
                                <strong><i class="fa fa-exclamation"></i> Warning - </strong>data yang anda cari Tidak Tersedia!
                              </div>
                            </div>
                          <?php else: ?>
                            <div class="header text-center">
                                <h4 class="title"><?php echo $nama_mapel->nama_mapel; ?></h4>
                                <p class="category">Kerjakan soal berikut dengan benar</p>
								                        <hr/>
                            </div>
                            <div class="content tryout-soal">

                              <div class="paginate pagination pagination-lg">
                                <div class="items">
                                <form action="<?php echo site_url('cek-TO-free') ?>" method="post">
                                  <input type="hidden" name="idMapel" value="<?php echo $mapel_id ?>" />
                                  <input type="hidden" name="idTo" value="<?php echo $to_id ?>" />
                                  <?php $i=1; ?>
                                  <?php foreach ($soal as $key): ?>
                                  <div class="konten">

                                    <div class="media">
                                      <div class="media-left">
                                        <span class="label label-primary lbl"><?php echo $i; ?></span>
                                      </div>
                                      <div class="media-body">
                                        <h4 class="media-heading breadcrumb"><?php echo $key->soal ;?></h4>
                                      </div>
                                    </div>


                                    <div class="radio">
                                      <label>
                                        <input type="radio" name="pil[<?=$key->id_soal?>]" value="A" data-toggle="radio">
                                        <?php echo $key->pilA; ?>
                                      </label>
                                    </div>
                                    <div class="radio">
                                      <label>
                                        <input type="radio" name="pil[<?=$key->id_soal?>]" value="B" data-toggle="radio">
                                        <?php echo $key->pilB; ?>
                                      </label>
                                    </div>
                                    <div class="radio">
                                      <label>
                                        <input type="radio" name="pil[<?=$key->id_soal?>]" value="C" data-toggle="radio">
                                        <?php echo $key->pilC; ?>
                                      </label>
                                    </div>
                                    <div class="radio">
                                      <label>
                                        <input type="radio" name="pil[<?=$key->id_soal?>]" value="D" data-toggle="radio">
                                        <?php echo $key->pilD; ?>
                                      </label>
                                    </div>
                                    <div class="radio">
                                      <label>
                                        <input type="radio" name="pil[<?=$key->id_soal?>]" value="E" data-toggle="radio">
                                        <?php echo $key->pilE; ?>
                                      </label>
                                    </div>

                                  </div>
                                  <?php $i++; ?>

                            <?php endforeach; ?>

                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-12">
                                      <ul class="pagination pager">
                                        <li><a href="#" class="firstPage">&laquo;</a></li>
                                        <li><a href="#" class="previousPage">&lsaquo;</a></li>
                                        <li class="pageNumbers"></li>
                                        <li><a href="#" class="nextPage">&rsaquo;</a></li>
                                        <li><a href="#" class="lastPage">&raquo;</a></li>
                                        <li><button type="submit" class="btn btn-primary btn-fill" onclick="return confirm('yakin nggak nih?');"><i class="fa fa-check"></i> Selesai</a></li>
                                      </ul>


                                  </div>

                                </div>
                                </form>

                              </div>

                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

<!-- end modular -->
<?php $this->load->view('PesertaModular/Free/Footer'); ?>
