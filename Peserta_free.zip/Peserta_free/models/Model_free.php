<?php
class Model_free extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}

	// public function insert_agenda($data){
	// 	$this->db->insert('agenda', $data);
	// }
	function login($username, $password) {
		   $this->db->select('username, password, status');
		   $this->db->from('peserta');
		   $this->db->where('username', $username);
		   $this->db->where('password', MD5($password));
		   $this->db->limit(1);

		   $query=$this->db->get();

		   if($query->num_rows()==1) {
		     return $query->result();
		   } else {
		     return false;
		   }
		 }

	public function select_akun($usernameForm, $passwordForm) {

		        $hasil = $this->db->query("SELECT username, password, status
		FROM `peserta` WHERE `username` = '".$usernameForm."' AND `password`= '".$passwordForm."'
		");
		        return $hasil;
		    }

	function lihat($sampai,$dari){
		return $query = $this->db->get('tb_barang',$sampai,$dari)->result();

	}

	public function select_all(){
		$this->db->select('*');
		$this->db->from('peserta');
		// $this->db->order_by('date_modified', "desc");

		return $this->db->get();
	}

	public function select_profil($id_profil){
		$this->db->select('*');
		$this->db->from('peserta');
		$this->db->join('kelompok_ujian', 'kelompok_ujian.id_kelompok_ujian = peserta.kelompok_ujian');
		$this->db->where('id_peserta', $id_profil);
		// $this->db->order_by('date_modified', "desc");

		return $this->db->get();
	}

	public function select_tryout($id_profil){
		$this->db->select('id_try_out','tanggal_ujian','kelompok_ujian');
		$this->db->from('try_out');
		$this->db->join('kelompok_ujian', 'kelompok_ujian.id_kelompok_ujian = try_out.id_kelompok_ujian');
		$this->db->join('peserta', 'peserta.kelompok_ujian = kelompok_ujian.id_kelompok_ujian');
		$this->db->where('peserta.id_peserta', $id_profil);
		$this->db->order_by('try_out.id_try_out', "desc");

		return $this->db->get();
	}

	// public function select_mapel($id_profil){
	// 	$this->db->select('nama_mapel','jumlah_soal','waktu');
	// 	$this->db->from('mata_pelajaran');
	// 	$this->db->join('try_out', 'mata_pelajaran.id_tryout = try_out.id_try_out');
	// 	$this->db->join('kelompok_ujian', 'kelompok_ujian.id_kelompok_ujian = try_out.id_kelompok_ujian');
	// 	$this->db->join('peserta', 'peserta.kelompok_ujian = kelompok_ujian.id_kelompok_ujian');
	// 	$this->db->where('peserta.id_peserta', $id_profil);
	//
	// 	return $this->db->get();
	// }

	public function select_detail_tryout($id_try, $id_peserta){
		$this->db->select('*');
		$this->db->from('mata_pelajaran');
		$this->db->join('try_out', 'mata_pelajaran.id_tryout = try_out.id_try_out');
		$this->db->join('kelompok_ujian', 'kelompok_ujian.id_kelompok_ujian = try_out.id_kelompok_ujian');
		$this->db->join('peserta', 'peserta.kelompok_ujian = kelompok_ujian.id_kelompok_ujian');
		$this->db->where('peserta.id_peserta', $id_peserta);
		$this->db->where('try_out.id_try_out', $id_try);

		return $this->db->get();
	}

	public function tampil_soal_tryout($id, $idTo){
		$this->db->select('*');
		$this->db->from('soal_ujian');
		$this->db->join('mata_pelajaran', 'mata_pelajaran.id_mapel = soal_ujian.id_mapel');
		$this->db->where('soal_ujian.id_mapel', $id);
		$this->db->where('soal_ujian.id_tryout', $idTo);
		// $this->db->limit(5,0);
		// $this->db->order_by("RAND ()");

		return $this->db->get();
	}

  public function jawaban_soal_tryout($id, $idTo){
    $this->db->select('id_soal ,jawaban_benar');
    $this->db->from('soal_ujian');
    $this->db->join('mata_pelajaran', 'mata_pelajaran.id_mapel = soal_ujian.id_mapel');
    $this->db->where('soal_ujian.id_mapel', $id);
    $this->db->where('soal_ujian.id_tryout', $idTo);
    // $this->db->limit(5,0);
    // $this->db->order_by("RAND ()");
		$query = $this->db->get();
    return $query->result_array();
  }

	public function select_fav(){
		$this->db->select('*');
		$this->db->from('penjualan');
		// $this->db->order_by('date_modified', "desc");

		return $this->db->get();
	}

	public function update_barang($id, $data){
		$this->db->where('id_barang', $id);
		$this->db->update('tb_barang', $data);
	}

	public function insertPeserta($data){
		$this->db->insert('peserta', $data);
	}

	public function delete($id){
		$this->db->where('id_barang', $id);
		$this->db->delete('tb_barang');
	}

	public function semua_barang($num,$offset){
		$this->db->order_by('id_barang');
		$data = $this->db->get('tb_barang', $num, $offset);
		return $data->result();
	}

	public function totalP(){
		// $this->db->select_sum('total');
		// $query = $this->db->from('penjualan');
		$this->db->select_sum('total');
		$query = $this->db->get('penjualan');
    	return $query->result();
	}

}
